// Pi Communications
// Rob Dobson 2018

#include "PiComms.h"

HardwareSerial* PiComms::_pSerial = NULL;

