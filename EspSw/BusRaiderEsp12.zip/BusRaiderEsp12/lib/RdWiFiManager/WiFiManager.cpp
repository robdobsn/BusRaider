// WiFi Manager
// Rob Dobson 2018

#include "WiFiManager.h"

StatusLed *WiFiManager::_pStatusLed = NULL;

String WiFiManager::_hostname;
